# Gemini Coder

Minimal Android coding chatbot powered only by **Google Gemini** (paid API key).

Stream responses, attach source files, export multi-file projects as **ZIP**.

---

## Download APK from GitHub Actions

1. Push this repo to GitHub (or fork it).
2. Open **Actions** tab → workflow **Build APK**.
3. After a green run, open the run → **Artifacts**.
4. Download **`GeminiCoder-debug`** (or release unsigned if you triggered that job).
5. Install on device (enable “Install unknown apps” if needed).

### Trigger builds

| Event | What builds |
|--------|-------------|
| Push / PR to `main` or `master` | Debug APK |
| **Actions → Run workflow** (manual) | Debug + unsigned Release |
| GitHub Release / tag | Debug + unsigned Release |

No secrets required for debug builds.

---

## Features

- Streaming SSE to Gemini API
- Models (Nov 2026):
  - `gemini-4-carbon` — Pro-class, best for software engineering
  - `gemini-4-argon` / `gemini-4-hydrogen`
  - `gemini-3.1-pro-preview`
  - `gemini-3.8-flash` / `gemini-3.5-flash-lite`
- API key stored with AES-256-GCM + Android Keystore
- Attach code/text/images (up to 15 MB)
- Export all code blocks as files or a single **ZIP**
- Session history capped for memory

---

## Local build (Android Studio)

1. Open this folder in Android Studio (Ladybug / 2024.2+).
2. Let Gradle sync (JDK 17).
3. Run on device/emulator (API 26+).

CLI:

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

---

## First run in the app

1. Open **Settings** (gear).
2. Paste a **paid** Gemini API key from [Google AI Studio](https://aistudio.google.com/apikey).
3. Pick a model (default: Carbon).
4. Chat about code. Use the ZIP icon on assistant messages to export projects.

---

## Project layout

```
.
├── .github/workflows/build.yml   # CI → APK artifact
├── app/src/main/java/com/geminicoder/
│   ├── Gemini.kt       # stream + attachments
│   ├── Secrets.kt      # encrypted key
│   ├── Store.kt        # sessions
│   ├── ChatScreen.kt   # UI + export ZIP
│   └── …
├── gradlew
└── README.md
```

Only Gemini-related streaming/security code was taken from the original KakhPhone project; the rest is a focused coding chatbot.

---

## Requirements

- minSdk 26, target/compileSdk 35
- JDK 17
- Internet permission (Gemini API only)
