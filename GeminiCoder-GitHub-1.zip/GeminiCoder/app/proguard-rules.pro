# Keep streaming / reflection-free JSON usage
-keepclassmembers class * {
    @androidx.compose.runtime.* <methods>;
}
-dontwarn org.json.**
