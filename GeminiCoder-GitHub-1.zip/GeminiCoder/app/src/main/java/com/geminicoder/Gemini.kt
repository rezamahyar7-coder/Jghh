package com.geminicoder

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// ---------- Models (Nov 2026 – best for coding) ----------
// Gemini 4 dropped the "Pro" name: Carbon = flagship Pro-class for software engineering.
data class ModelOpt(val id: String, val label: String)

val MODELS = listOf(
    ModelOpt("gemini-4-carbon", "Carbon · Pro-class (best coding)"),
    ModelOpt("gemini-4-argon", "Argon · frontier, faster"),
    ModelOpt("gemini-4-hydrogen", "Hydrogen · everyday coding"),
    ModelOpt("gemini-3.1-pro-preview", "3.1 Pro (preview)"),
    ModelOpt("gemini-3.8-flash", "3.8 Flash · fast"),
    ModelOpt("gemini-3.5-flash-lite", "3.5 Flash-Lite · cheapest")
)


const val MAX_FILE_BYTES = 15 * 1024 * 1024   // 15 MB

// ---------- Data ----------
data class Part(val text: String? = null, val mime: String? = null, val b64: String? = null)
data class Turn(val role: String, val parts: List<Part>)
data class Att(val name: String, val mime: String, val b64: String?, val text: String?)

/**
 * Streaming call to Gemini (SSE).
 * Reuses the proven streaming logic from KakhPhone.
 * Returns totalTokenCount when available.
 */
suspend fun geminiStream(
    key: String,
    model: String,
    system: String,
    turns: List<Turn>,
    jsonMode: Boolean = false,
    onDelta: suspend (String) -> Unit
): Int = withContext(Dispatchers.IO) {
    val contents = JSONArray()
    turns.forEach { t ->
        val ps = JSONArray()
        t.parts.forEach { p ->
            if (p.text != null) ps.put(JSONObject().put("text", p.text))
            else ps.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", p.mime).put("data", p.b64)
                )
            )
        }
        contents.put(JSONObject().put("role", t.role).put("parts", ps))
    }

    val body = JSONObject().put("contents", contents)
    if (jsonMode) {
        body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
    }
    if (system.isNotBlank()) {
        body.put(
            "systemInstruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
        )
    }

    val url = URL(
        "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"
    )
    val conn = url.openConnection() as HttpURLConnection
    conn.requestMethod = "POST"
    conn.doOutput = true
    conn.connectTimeout = 20_000
    conn.readTimeout = 180_000
    conn.setRequestProperty("Content-Type", "application/json")
    conn.setRequestProperty("x-goog-api-key", key)

    // Cancel → disconnect
    kotlin.coroutines.coroutineContext[Job]?.invokeOnCompletion {
        try { conn.disconnect() } catch (_: Exception) {}
    }

    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

    val code = conn.responseCode
    if (code !in 200..299) {
        val err = conn.errorStream?.bufferedReader()?.readText() ?: ""
        val msg = try {
            JSONObject(err).getJSONObject("error").getString("message")
        } catch (_: Exception) {
            "HTTP $code"
        }
        throw IllegalStateException(msg)
    }

    var tokens = 0
    conn.inputStream.bufferedReader().useLines { lines ->
        for (line in lines) {
            if (!line.startsWith("data:")) continue
            val j = try {
                JSONObject(line.substring(5).trim())
            } catch (_: Exception) {
                continue
            }
            j.optJSONObject("usageMetadata")?.let {
                tokens = it.optInt("totalTokenCount", tokens)
            }
            val parts = j.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts") ?: continue

            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                sb.append(parts.getJSONObject(i).optString("text"))
            }
            if (sb.isNotEmpty()) {
                withContext(Dispatchers.Main) { onDelta(sb.toString()) }
            }
        }
    }
    tokens
}

/** Read an attachment (text files kept as text, others base64). */
fun readAttachment(ctx: Context, uri: Uri): Att? {
    val cr = ctx.contentResolver
    var name = "file"
    cr.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) name = c.getString(i) ?: name
        }
    }
    val mime = cr.getType(uri) ?: "application/octet-stream"
    val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: return null
    if (bytes.size > MAX_FILE_BYTES) return null

    val ext = name.substringAfterLast('.', "").lowercase()
    val isText = mime.startsWith("text/") ||
        mime in setOf("application/json", "application/xml", "application/javascript") ||
        ext in setOf(
            "txt", "md", "json", "csv", "kt", "kts", "java", "py", "js", "ts", "tsx",
            "html", "css", "xml", "yml", "yaml", "gradle", "toml", "rs", "go", "c", "cpp",
            "h", "hpp", "swift", "dart", "sql", "sh", "log", "srt"
        )

    return if (isText) {
        Att(name, "text/plain", null, String(bytes, Charsets.UTF_8))
    } else {
        Att(name, mime, Base64.encodeToString(bytes, Base64.NO_WRAP), null)
    }
}
