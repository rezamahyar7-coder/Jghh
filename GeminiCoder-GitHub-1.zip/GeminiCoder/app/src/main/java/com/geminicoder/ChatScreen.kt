package com.geminicoder

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

private val CODING_SYS = """
You are an expert coding assistant.
- Write clean, production-ready code. Prefer modern best practices.
- When creating files, ALWAYS put each file in its own markdown code block with the filename after a colon, e.g.:
  ```kotlin:app/src/Main.kt
  // full file content
  ```
  ```xml:app/src/main/AndroidManifest.xml
  ...
  ```
- For multi-file projects, output every file this way (one block per file). The app will save them all and can zip them.
- Explain briefly first, then the code blocks.
- If the user pastes code, diagnose and fix it.
- Answer in the same language the user writes in.
""".trimIndent()

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("chat", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    val sessions = remember {
        mutableStateListOf<Session>().also {
            it.addAll(Store.load(ctx))
            if (it.isEmpty()) it.add(Session(System.currentTimeMillis().toString(), "New chat"))
        }
    }
    var curId by remember {
        mutableStateOf(
            prefs.getString("cur", null)
                ?.takeIf { id -> sessions.any { it.id == id } }
                ?: sessions[0].id
        )
    }
    fun cur() = sessions.firstOrNull { it.id == curId } ?: sessions[0]

    var ver by remember { mutableStateOf(0) }
    ver // force read
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    var panel by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var model by remember {
        mutableStateOf(
            prefs.getString("model", MODELS[0].id) ?: MODELS[0].id
        )
    }
    var key by remember { mutableStateOf(Secrets.get(prefs, "key")) }
    var sendHistory by remember { mutableStateOf(prefs.getBoolean("hist", true)) }
    val atts = remember { mutableStateListOf<Att>() }
    val listState = rememberLazyListState()

    fun persist() = Store.save(ctx, sessions)

    fun newSession() {
        val s = Session(System.currentTimeMillis().toString(), "New chat")
        sessions.add(0, s)
        curId = s.id
        prefs.edit().putString("cur", s.id).apply()
        persist()
    }

    LaunchedEffect(curId, cur().messages.size, ver) {
        if (cur().messages.isNotEmpty()) {
            listState.animateScrollToItem(cur().messages.size - 1)
        }
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        uris.forEach { u ->
            val a = readAttachment(ctx, u)
            if (a == null) {
                Toast.makeText(ctx, "File too large (max 15 MB) or unreadable", Toast.LENGTH_SHORT).show()
            } else {
                atts.add(a)
            }
        }
    }

    fun ask(userText: String, files: List<Att>, regenerate: Boolean = false) {
        if (key.isBlank()) {
            settings = true
            return
        }
        val session = cur()
        if (!regenerate) {
            session.messages.add(Msg(true, userText, files.map { it.name }))
            if (session.title == "New chat") {
                session.title = userText.take(40).ifBlank { files.firstOrNull()?.name ?: "New chat" }
            }
        }
        // assistant placeholder
        session.messages.add(Msg(false, ""))
        ver++
        persist()
        busy = true

        job = scope.launch {
            try {
                val turns = mutableListOf<Turn>()
                val msgs = if (sendHistory) session.messages.dropLast(1) else session.messages.takeLast(2).dropLast(1)

                // limit history for memory / token cost
                val limited = msgs.takeLast(24)
                for (m in limited) {
                    val parts = mutableListOf<Part>()
                    if (m.text.isNotBlank()) parts.add(Part(text = m.text))
                    // note: previous file contents are not re-sent to keep memory low
                    turns.add(Turn(if (m.isUser) "user" else "model", parts))
                }

                // current user turn with attachments
                val userParts = mutableListOf<Part>()
                if (userText.isNotBlank()) userParts.add(Part(text = userText))
                files.forEach { f ->
                    if (f.text != null) {
                        userParts.add(Part(text = "--- file: ${f.name} ---\n${f.text}"))
                    } else if (f.b64 != null) {
                        userParts.add(Part(mime = f.mime, b64 = f.b64))
                    }
                }
                turns.add(Turn("user", userParts))

                var acc = ""
                val tokens = geminiStream(key, model, CODING_SYS, turns) { delta ->
                    acc += delta
                    val idx = session.messages.lastIndex
                    if (idx >= 0) {
                        session.messages[idx] = Msg(false, acc)
                        ver++
                    }
                }
                val idx = session.messages.lastIndex
                if (idx >= 0) {
                    session.messages[idx] = Msg(false, acc, tokens = tokens)
                    ver++
                }
            } catch (e: Exception) {
                val idx = session.messages.lastIndex
                if (idx >= 0 && session.messages[idx].text.isBlank()) {
                    session.messages[idx] = Msg(false, "⚠️ ${e.message ?: "Error"}")
                } else {
                    session.messages.add(Msg(false, "⚠️ ${e.message ?: "Error"}"))
                }
                ver++
            } finally {
                busy = false
                persist()
            }
        }
    }

    fun send() {
        val text = input.trim()
        if (text.isBlank() && atts.isEmpty()) return
        val files = atts.toList()
        atts.clear()
        input = ""
        ask(text, files)
    }

    // ---------- UI ----------
    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // Top bar
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Outlined.Menu, null, tint = Teal,
                    modifier = Modifier.size(28.dp).clickable { panel = true }
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(cur().title, color = TextMain, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(model, color = TextSec, fontSize = 11.sp)
                }
                Icon(
                    Icons.Outlined.Settings, null, tint = TextSec,
                    modifier = Modifier.size(26.dp).clickable { settings = true }
                )
            }

            // Messages
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(cur().messages, key = { i, _ -> i }) { _, msg ->
                    MessageBubble(msg)
                }
            }

            // Attachments preview
            if (atts.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    atts.forEach { a ->
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Surface2)
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(a.name, color = TextSec, fontSize = 12.sp, maxLines = 1)
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                Icons.Outlined.Close, null, tint = TextSec,
                                modifier = Modifier.size(14.dp).clickable { atts.remove(a) }
                            )
                        }
                    }
                }
            }

            // Input row
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Surface)
                    .border(1.dp, TealDim, RoundedCornerShape(24.dp))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Outlined.AttachFile, null, tint = TextSec,
                    modifier = Modifier.size(28.dp).clickable { picker.launch("*/*") }
                )
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 10.dp),
                    textStyle = TextStyle(color = TextMain, fontSize = 16.sp, textDirection = TextDirection.Content),
                    cursorBrush = SolidColor(Teal),
                    maxLines = 6,
                    decorationBox = { inner ->
                        Box {
                            if (input.isEmpty()) Text("Ask about code…", color = TextSec, fontSize = 16.sp)
                            inner()
                        }
                    }
                )
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (busy) ErrorRed else Teal)
                        .clickable {
                            if (busy) job?.cancel()
                            else send()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (busy) Icons.Outlined.Stop else Icons.Outlined.ArrowUpward,
                        null, tint = Bg, modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        // Sessions panel
        if (panel) {
            Row(Modifier.fillMaxSize()) {
                Column(
                    Modifier
                        .width(280.dp)
                        .fillMaxHeight()
                        .background(Surface)
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Chats", color = Teal, fontSize = 18.sp, modifier = Modifier.weight(1f))
                        Icon(
                            Icons.Outlined.AddComment, null, tint = Teal,
                            modifier = Modifier.clickable {
                                if (!busy) {
                                    newSession()
                                    panel = false
                                }
                            }
                        )
                    }
                    LazyColumn(Modifier.weight(1f)) {
                        items(sessions.size) { i ->
                            val s = sessions[i]
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .background(if (s.id == curId) Surface2 else Bg)
                                    .clickable {
                                        if (!busy) {
                                            curId = s.id
                                            prefs.edit().putString("cur", s.id).apply()
                                            panel = false
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    s.title, color = TextMain, fontSize = 14.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(
                                    Icons.Outlined.DeleteOutline, null, tint = TextSec,
                                    modifier = Modifier.size(18.dp).clickable {
                                        if (!busy) {
                                            sessions.remove(s)
                                            if (sessions.isEmpty()) newSession()
                                            else if (s.id == curId) curId = sessions[0].id
                                            persist()
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(androidx.compose.ui.graphics.Color(0x99000000))
                        .clickable { panel = false }
                )
            }
        }

        // Settings sheet
        if (settings) {
            SettingsOverlay(
                key = key,
                model = model,
                sendHistory = sendHistory,
                onKey = { key = it; Secrets.put(prefs, "key", it) },
                onModel = { model = it; prefs.edit().putString("model", it).apply() },
                onHist = { sendHistory = it; prefs.edit().putBoolean("hist", it).apply() },
                onClose = { settings = false }
            )
        }
    }
}

@Composable
private fun MessageBubble(msg: Msg) {
    val ctx = LocalContext.current
    val isUser = msg.isUser
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            Modifier
                .widthIn(max = 340.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(if (isUser) UserBubble else Surface)
                .padding(12.dp)
        ) {
            if (msg.files.isNotEmpty()) {
                msg.files.forEach {
                    Text("📎 $it", color = TextSec, fontSize = 12.sp)
                }
                Spacer(Modifier.height(4.dp))
            }
            SelectionContainer {
                Text(
                    text = if (isUser) androidx.compose.ui.text.AnnotatedString(msg.text)
                    else renderMarkdown(msg.text),
                    color = TextMain,
                    fontSize = 15.sp,
                    style = TextStyle(textDirection = TextDirection.Content, lineHeight = 22.sp)
                )
            }
            if (!isUser && msg.text.isNotBlank()) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (msg.tokens > 0) {
                        Text("${msg.tokens} tok", color = TextSec, fontSize = 10.sp)
                        Spacer(Modifier.width(8.dp))
                    }
                    // Copy
                    Icon(
                        Icons.Outlined.ContentCopy, null, tint = TextSec,
                        modifier = Modifier.size(16.dp).clickable {
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("code", msg.text))
                            Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                        }
                    )
                    Spacer(Modifier.width(12.dp))
                    // Save code blocks / ZIP project
                    Icon(
                        Icons.Outlined.FolderZip, null, tint = TextSec,
                        modifier = Modifier.size(16.dp).clickable {
                            exportCodeBlocks(ctx, msg.text)
                        }
                    )
                    Spacer(Modifier.width(10.dp))
                    Icon(
                        Icons.Outlined.Save, null, tint = TextSec,
                        modifier = Modifier.size(16.dp).clickable {
                            exportCodeBlocks(ctx, msg.text, zip = false)
                        }
                    )
                }
            }
        }
    }
}

/**
 * Extract ALL fenced code blocks (with optional filename after colon).
 * - zip=true  → write every file into a folder, then produce a .zip and share it
 * - zip=false → save each file separately and share the first / show count
 */
private fun exportCodeBlocks(ctx: Context, full: String, zip: Boolean = true) {
    // ```lang:path/to/File.ext  OR  ```lang
    val regex = Regex("```([\\w.+-]*)(?::([^\\n`]+))?\\n([\\s\\S]*?)```")
    val blocks = regex.findAll(full).mapIndexed { i, m ->
        val lang = m.groupValues[1].ifBlank { "txt" }
        val named = m.groupValues[2].trim().trimStart('/', '\\')
        val body = m.groupValues[3].trimEnd()
        val name = when {
            named.isNotBlank() -> named
            else -> "snippet_${i + 1}.${lang.takeWhile { it.isLetterOrDigit() }.ifBlank { "txt" }}"
        }
        name to body
    }.toList()

    if (blocks.isEmpty()) {
        // no fences → save whole reply as markdown
        saveAndShare(ctx, listOf("response.md" to full), zip = false)
        return
    }
    saveAndShare(ctx, blocks, zip = zip)
}

private fun saveAndShare(ctx: Context, files: List<Pair<String, String>>, zip: Boolean) {
    try {
        val base = File(ctx.getExternalFilesDir(null), "exports").apply { mkdirs() }
        // clear previous export folder content for cleanliness (optional)
        val stamp = System.currentTimeMillis().toString().takeLast(6)
        val outDir = File(base, "proj_$stamp").apply { mkdirs() }

        files.forEach { (rel, content) ->
            val safe = rel.replace("..", "_").replace('\\', '/')
            val f = File(outDir, safe)
            f.parentFile?.mkdirs()
            f.writeText(content)
        }

        val shareFile: File
        val mime: String
        if (zip && files.size >= 1) {
            shareFile = File(base, "project_$stamp.zip")
            zipFolder(outDir, shareFile)
            mime = "application/zip"
            Toast.makeText(ctx, "ZIP: ${files.size} file(s)", Toast.LENGTH_SHORT).show()
        } else {
            // single file or user asked for separate saves
            shareFile = File(outDir, files.first().first.substringAfterLast('/'))
            if (!shareFile.exists()) {
                // write first to flat path for sharing
                shareFile.writeText(files.first().second)
            }
            mime = "text/plain"
            Toast.makeText(ctx, "Saved ${files.size} file(s)", Toast.LENGTH_SHORT).show()
        }

        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", shareFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, if (zip) "Share ZIP" else "Share file"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

/** Simple zip of a directory (no external deps). */
private fun zipFolder(srcDir: File, zipFile: File) {
    java.util.zip.ZipOutputStream(zipFile.outputStream().buffered()).use { zos ->
        srcDir.walkTopDown().filter { it.isFile }.forEach { file ->
            val entryName = file.relativeTo(srcDir).path.replace('\\', '/')
            zos.putNextEntry(java.util.zip.ZipEntry(entryName))
            file.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }
}

@Composable
private fun SettingsOverlay(
    key: String,
    model: String,
    sendHistory: Boolean,
    onKey: (String) -> Unit,
    onModel: (String) -> Unit,
    onHist: (Boolean) -> Unit,
    onClose: () -> Unit
) {
    var keyEdit by remember { mutableStateOf(key) }
    Box(
        Modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color(0xCC000000))
            .clickable(onClick = onClose),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(16.dp))
                .background(Surface)
                .clickable(enabled = false) {}
                .padding(20.dp)
        ) {
            Text("Settings", color = Teal, fontSize = 20.sp)
            Spacer(Modifier.height(16.dp))

            Text("Gemini API Key (paid)", color = TextSec, fontSize = 13.sp)
            OutlinedTextField(
                value = keyEdit,
                onValueChange = { keyEdit = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                textStyle = TextStyle(color = TextMain, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Teal,
                    unfocusedBorderColor = TealDim,
                    cursorColor = Teal
                )
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { onKey(keyEdit.trim()); onClose() },
                colors = ButtonDefaults.buttonColors(containerColor = Teal)
            ) {
                Text("Save key", color = Bg)
            }

            Spacer(Modifier.height(20.dp))
            Text("Model", color = TextSec, fontSize = 13.sp)
            MODELS.forEach { m ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onModel(m.id) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = model == m.id,
                        onClick = { onModel(m.id) },
                        colors = RadioButtonDefaults.colors(selectedColor = Teal)
                    )
                    Column {
                        Text(m.label, color = TextMain, fontSize = 14.sp)
                        Text(m.id, color = TextSec, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = sendHistory,
                    onCheckedChange = onHist,
                    colors = SwitchDefaults.colors(checkedTrackColor = Teal)
                )
                Spacer(Modifier.width(8.dp))
                Text("Send chat history (more tokens)", color = TextMain, fontSize = 14.sp)
            }

            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onClose) {
                Text("Close", color = TextSec)
            }
        }
    }
}
