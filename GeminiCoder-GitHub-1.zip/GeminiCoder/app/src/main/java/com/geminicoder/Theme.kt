package com.geminicoder

import androidx.compose.ui.graphics.Color

val Bg        = Color(0xFF0A0F14)
val Surface   = Color(0xFF111820)
val Surface2  = Color(0xFF161E28)
val Teal      = Color(0xFF00C9A7)
val TealDim   = Color(0xFF0D3D38)
val TextMain  = Color(0xFFE8EEF4)
val TextSec   = Color(0xFF8B9AAB)
val CodeGreen = Color(0xFF58E6A0)
val CodeBg    = Color(0xFF0A1E26)
val UserBubble = Color(0xFF1A3A42)
val ErrorRed  = Color(0xFFFF6B6B)
