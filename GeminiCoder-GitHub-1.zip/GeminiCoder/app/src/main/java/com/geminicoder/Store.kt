package com.geminicoder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Msg(
    val isUser: Boolean,
    val text: String,
    val files: List<String> = emptyList(),
    val tokens: Int = 0
)

class Session(
    val id: String,
    var title: String,
    val messages: MutableList<Msg> = mutableListOf()
)

/**
 * Lightweight session store.
 * - Only keeps last N messages per session in memory for the active chat.
 * - Persists to SharedPreferences (compact JSON).
 * - Caps total sessions to avoid memory growth.
 */
object Store {
    private const val PREFS = "chat"
    private const val MAX_SESSIONS = 30
    private const val MAX_MSGS_PER_SESSION = 80   // hard cap for memory

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Session> {
        val out = mutableListOf<Session>()
        try {
            val arr = JSONArray(prefs(c).getString("sessions", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val msgs = mutableListOf<Msg>()
                val ma = o.getJSONArray("m")
                // keep only the newest MAX_MSGS_PER_SESSION
                val start = (ma.length() - MAX_MSGS_PER_SESSION).coerceAtLeast(0)
                for (k in start until ma.length()) {
                    val m = ma.getJSONObject(k)
                    val fa = m.optJSONArray("f")
                    val files = (0 until (fa?.length() ?: 0)).map { fa!!.getString(it) }
                    msgs.add(Msg(m.getBoolean("u"), m.getString("t"), files, m.optInt("k")))
                }
                out.add(Session(o.getString("id"), o.getString("title"), msgs))
            }
        } catch (_: Exception) {}
        return out
    }

    fun save(c: Context, list: List<Session>) {
        val trimmed = list.take(MAX_SESSIONS)
        val arr = JSONArray()
        trimmed.forEach { s ->
            val ma = JSONArray()
            // persist only newest messages
            val start = (s.messages.size - MAX_MSGS_PER_SESSION).coerceAtLeast(0)
            for (i in start until s.messages.size) {
                val m = s.messages[i]
                ma.put(
                    JSONObject()
                        .put("u", m.isUser)
                        .put("t", m.text)
                        .put("f", JSONArray(m.files))
                        .put("k", m.tokens)
                )
            }
            arr.put(
                JSONObject()
                    .put("id", s.id)
                    .put("title", s.title)
                    .put("m", ma)
            )
        }
        prefs(c).edit().putString("sessions", arr.toString()).apply()
    }
}
