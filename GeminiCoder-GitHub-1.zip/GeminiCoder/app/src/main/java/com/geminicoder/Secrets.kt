package com.geminicoder

import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * API keys stored with AES-256-GCM. Key never leaves Android Keystore.
 * Format: "v1:<iv>:<ciphertext>" (base64).
 */
object Secrets {
    private const val ALIAS = "geminicoder_key_v1"
    private const val TAG = "v1:"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    private fun encrypt(plain: String): String? = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        TAG + Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(c.doFinal(plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    } catch (_: Exception) { null }

    private fun decrypt(s: String): String? = try {
        val p = s.removePrefix(TAG).split(":")
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)))
        String(c.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), Charsets.UTF_8)
    } catch (_: Exception) { null }

    fun get(sp: SharedPreferences, name: String): String {
        val raw = sp.getString(name, "") ?: ""
        if (raw.isBlank()) return ""
        if (!raw.startsWith(TAG)) {
            put(sp, name, raw)
            return raw
        }
        return decrypt(raw) ?: ""
    }

    fun put(sp: SharedPreferences, name: String, value: String) {
        val v = if (value.isBlank()) "" else (encrypt(value) ?: value)
        sp.edit().putString(name, v).apply()
    }
}
