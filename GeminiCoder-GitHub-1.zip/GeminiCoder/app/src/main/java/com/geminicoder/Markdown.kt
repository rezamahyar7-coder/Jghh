package com.geminicoder

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Lightweight markdown renderer for chat (code blocks, bold, headers, lists). */
fun renderMarkdown(text: String): AnnotatedString = buildAnnotatedString {
    var inCode = false
    text.split("\n").forEachIndexed { li, raw ->
        if (li > 0) append("\n")
        if (raw.trimStart().startsWith("```")) {
            inCode = !inCode
            return@forEachIndexed
        }
        if (inCode) {
            withStyle(
                SpanStyle(
                    fontFamily = FontFamily.Monospace,
                    color = CodeGreen,
                    background = CodeBg,
                    fontSize = 13.sp
                )
            ) { append(raw) }
            return@forEachIndexed
        }
        var s = raw
        val h = Regex("^#{1,4}\\s+").find(s)
        if (h != null) {
            withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Teal, fontSize = 18.sp)) {
                append(s.substring(h.range.last + 1))
            }
            return@forEachIndexed
        }
        if (s.startsWith("- ") || s.startsWith("* ")) s = "• " + s.substring(2)

        var i = 0
        while (i < s.length) {
            if (s.startsWith("**", i)) {
                val e = s.indexOf("**", i + 2)
                if (e > 0) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) {
                        append(s.substring(i + 2, e))
                    }
                    i = e + 2
                    continue
                }
            }
            if (s[i] == '`') {
                val e = s.indexOf('`', i + 1)
                if (e > 0) {
                    withStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            color = CodeGreen,
                            background = CodeBg
                        )
                    ) { append(s.substring(i + 1, e)) }
                    i = e + 1
                    continue
                }
            }
            append(s[i])
            i++
        }
    }
}
